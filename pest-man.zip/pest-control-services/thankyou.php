

<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Pest Control Services in Delhi NCR|Rodent|Termite|Cockroaches-Complete Solution</title>
	<link rel="icon" href="images/pest-logo.png" type="image/gif" sizes="35x35">
	<!-- for-mobile-apps -->
	<meta name="description" content="We provide herbal and odour less pest control treatment on residential & commercial properties in Delhi NCR|Our trained team, ensure 100% removal of  pests from the property." />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Pest Control Services in Delhi NCR|Rodent|Termite|Cockroaches-Complete Solution" />
	<meta http-equiv="refresh" content="5;url=http://pest-man.com"/>
	<script> 
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //for-mobile-apps -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<!--banner slider  -->
	<link href="css/JiSlider.css" rel="stylesheet">
	<!-- //banner-slider -->
	<link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="//fonts.googleapis.com/css?family=Noto+Serif:400,400i,700,700i" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">

	<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '196717734305980');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=196717734305980&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-120200662-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-120200662-1');
</script>

<!-- Global site tag (gtag.js) - Google AdWords: 802040308 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-802040308"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-802040308');
</script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NCQHVKW');</script>
<!-- End Google Tag Manager -->

</head>

<body>

	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NCQHVKW"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

	<!-- Event snippet for PestMan Lead conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-802040308/jowNCIXwxYMBEPTTuP4C'});
</script>

	
	<!-- header -->
	<div class="w3layouts-header">
		<div class="container">
			<div class="logo-nav-agileits">
				<div class="logo-nav-left">
					<a href="#" style="color: #ed1b24; font-size: 16px; padding-right: 0em; font-weight: bold;">Choose Pestman for a range of Herbal and Odorless Pest Control Solutions </a>
				</div>
				
				<div class="header-grid-left-wthree">

					<ul>
						<li>
							<span class="fa fa-envelope" aria-hidden="true"></span>
							<a href="mailto:info@example.com">info@pest-man.com</a>
						</li>
					</ul>
					<!-- <ul>
						<li>
							<span class="fa fa-phone" aria-hidden="true"></span> 011-2715 2322
						</li>
					</ul> -->
					<ul>
						<li>
							<span class="fa fa-phone" aria-hidden="true"></span> +91 82-87-900-800
						</li>
					</ul>

					<div class="clearfix"> </div>
					
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!-- //header -->
	<!-- banner -->

	<div class="">
		<div class="banner-top banner-top1">
			<div class="container">
				
				<div class="banner-info info2">
					<h4>THANKS FOR CONTACTING US, WE WILL CONTACT YOU SOON</h4><br>
				</div>
			</div>
		</div>
	</div>
	<!-- //about -->

	<!-- footer -->

	<div class="cpy-footer">
		<div class="cpy-text">
			<p>© 2018 Pestman. All rights reserved | Design by
				<a href="http://uniworldstudios.com/">Uniworld Studios</a>
			</p>
		</div>

	</div>
	<!--//footer  -->
	<!-- js -->
	<script src="js/jquery-2.2.3.min.js"></script>
	<!-- //js-->
	<!--banner-slider-->
	<script src="js/JiSlider.js"></script>
	<script> 
		$(window).load(function () {
			$('#JiSlider').JiSlider({
				color: '#fff',
				start: 1,
				reverse: false
			}).addClass('ff')
		})
	</script>
	<!-- //banner-slider -->
	<!--search-bar-->
	<script src="js/main.js"></script>
	<!--//search-bar-->
	<!-- start-smooth-scrolling -->
	<script  src="js/move-top.js"></script>
	<script  src="js/easing.js"></script>
	<script> 
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();

				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- //end-smooth-scrolling -->
	<!-- smooth-scrolling-of-move-up -->
	<script> 
		$(document).ready(function () {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/

			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>
	<script  src="js/SmoothScroll.min.js"></script>
	<!-- Bootstrap core JavaScript
    ================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<script src="js/bootstrap.js"></script>
</body>

</html>