<?php

function getIp(){

        $ip = $_SERVER['REMOTE_ADDR'];     
        if($ip){
            if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            }
            return $ip;
        }
        // There might not be any data
        return false;
    }

$user_ip = getIp();



$email_from = 'sales@pest-man.com';
$subject = "A New Query Received for Pest Control";
$message = "You have received a new visitor from the Pestman Landing Page \n\n User Ip Address: $user_ip";
$headers = "From: $email_from \r\n";
// Message lines should not exceed 70 characters (PHP rule), so wrap it
$message = wordwrap($message, 70);
// Send Mail By PHP Mail Function
mail("uniworldstudiosgurugram@gmail.com", $subject, $message, $headers);


?>


<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Pest Control Services in Delhi NCR|Rodent|Termite|Cockroaches-Complete Solution</title>
	<link rel="icon" href="images/pest-logo.png" type="image/gif" sizes="35x35">
	<!-- for-mobile-apps -->
	<meta name="description" content="We provide herbal and odour less pest control treatment on residential & commercial properties in Delhi NCR|Our trained team, ensure 100% removal of  pests from the property." />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Pest Control Services in Delhi NCR|Rodent|Termite|Cockroaches-Complete Solution" />
	<meta name="p:domain_verify" content="cb5f71dc3f059557d917d3ee2d014867"/>
	<script> 
		addEventListener("load", function () {
			setTimeout(hideURLbar, 5);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //for-mobile-apps -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<!--banner slider  -->
	<link href="css/JiSlider.css" rel="stylesheet">
	<!-- //banner-slider -->
	<link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="//fonts.googleapis.com/css?family=Noto+Serif:400,400i,700,700i" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
	<!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script> -->
	<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
	<!-- <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
	<script>
		function blinker() {
			$('.blinking').fadeOut(300);
			$('.blinking').fadeIn(300);
		}
		setInterval(blinker, 2000);
	</script>

	<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '196717734305980');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=196717734305980&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-120200662-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-120200662-1');
</script>

<!-- Global site tag (gtag.js) - Google AdWords: 802040308 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-802040308"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-802040308');
</script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NCQHVKW');</script>
<!-- End Google Tag Manager -->



</head>

<body>

	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NCQHVKW"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

	<div class="se-pre-con"></div>
	<!-- header -->
	<div class="w3layouts-header">
		<div class="container">
			<div class="logo-nav-agileits">
				<div class="logo-nav-left">
					<div class="hidden-phone">
						<a href="#" style="color: #ed1b24; font-size: 16px; padding-right: 0em; font-weight: bold;">Choose Pestman for a range of Herbal and Odorless Pest Control Solutions </a>
					</div>
					
				</div>
				
				<div class="header-grid-left-wthree">

					<ul>
						<li>
							<span class="fa fa-envelope" aria-hidden="true"></span>
							<a href="mailto:info@example.com">info@pest-man.com</a>
						</li>
					</ul>
					<!-- <ul>
						<li>
							<span class="fa fa-phone" aria-hidden="true"></span> 011-2715 2322</li>
					</ul> -->
					<ul>
						<li>
							<span class="fa fa-phone" aria-hidden="true"><a href="tel:8287900800"> Call Now:82-87-900-800</a> </span> 
						</li>
					</ul>

					<div class="clearfix"> </div>
					
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
						
	<!-- //header -->
	<!-- banner -->

	<div class="banner-silder">

		<div id="JiSlider" class="jislider">
			<ul>
				<li>
					<div class="banner-top banner-top1">
						<div class="container">
							<div class="offer-image">
								<h1 class="blinking">
									<a><img src="images/cloud.png">
									</a>
								</h1>
							</div>
							<div class="banner-logo">
								<h1>
									<a href="index.php"><img src="images/pest-control.png">
									</a>
								</h1>
							</div>
							<div class="banner-info info2">
								<h3>WE CARE ABOUT YOUR PEST INFESTATION</h3><br>
							</div>
						</div>
					</div>
				</li>

				<li>
					<div class="banner-top banner-top2">
						<div class="container">
							<div class="offer-image">
								<h1 class="blinking">
									<a><img src="images/cloud.png">
									</a>
								</h1>
							</div>
							<div class="banner-logo">
								<h1>
									<a href="index.php"><img src="images/pest-control.png">
									</a>
								</h1>
							</div>
							<div class="banner-info bg3 info2">
								<h3>HERBAL PEST CONTROL TREATMENT</h3><br>
							</div>

						</div>
					</div>
				</li>

				<li>
					<div class="banner-top banner-top3">
						<div class="container">
							<div class="offer-image">
								<h1 class="blinking">
									<a><img src="images/cloud.png">
									</a>
								</h1>
							</div>
							<div class="banner-logo">
								<h1>
									<a href="index.php"><img src="images/pest-control.png">
									</a>
								</h1>
							</div>
							<div class="banner-info bg3">
								<h3>ODOR LESS TREATMENT</h3><br>
							</div>
						</div>
					</div>
				</li>
			</ul>
		</div>
		<!-- //banner -->
		<!-- banner bottom -->
		<div class="banner-btm">
			<div class="container">
				<div class="banner-bottom-main">
					<div class="col-md-4 banner-btmg1"><br><br>
						<div class="form-text">
							<h3>Looking for Pest Control Services</h3>
							<p>We are expert in our services</p>
							<img src="images/f1.png" alt="" />
						</div><br>
						<form action="email.php" method="post" class="banner_form">
							<div class="sec-left">
								<label class="contact-form-text">Name</label>
								<input placeholder="Your Name " name="name" type="text" required="">
							</div>
							<div class="sec-right">
								<label class="contact-form-text">Email</label>
								<input placeholder="Your Email(Optional) " name="email" type="email">
							</div>
							<div class="sec-left">
								<label class="contact-form-text">Mobile no.</label>
								<input placeholder="Your Mobile" name="mobile" type="text" pattern="[0-9]{1}[0-9]{9}" required="">
							</div>
							<div class="form-tx">
								<label class="contact-form-text">Address</label>
								<textarea placeholder="Your Address (Optional)" name="address"></textarea>
							</div>
							<div class="form-select sec-right">
								<label class="contact-form-text">Select Service</label>
								<select name="service">
									<option value="0">---- SELECT ----</option>
									<option value="Residental Pest Control">Residental Pest Control</option>
									<option value="Commercial Pest Control">Commercial Pest Control</option>
									<option value="Pest Prevention">Pest Prevention</option>
									<option value="Others">Others</option>
								</select>
							</div>
							<input type="submit" value="Submit" name="submit">
						</form>
					</div>
					<div class="col-md-8 banner-btm-grid2">
						<div class="col-md-4 banner-grid2">
							<div class="banner-subg1">
								<i class="fa fa-home" style="font-size:36px"></i>
								<h3>Residental Pest Control</h3>
								<p>We provide the best pest control services in Delhi-NCR, driven by technology and eco-friendly insecticides to destroy any pest that has already established a presence in your living space. Our experienced team, do a detailed inspection and customize the chemicals according to the need for specific kind of pest to check their future growth.</p>
							</div>
							<div class="banner-subg1">
								<i class="fa fa-building" style="font-size:36px"></i>
								<h3>Commercial Pest Control</h3>
								<p>We offer to customize pest control services according to the specific business whether it is a hotel, hospital or bank. Every business has a specific type of pest and requires chemicals accordingly. We do a thorough inspection before taking any action against the pest so that we can eliminate them effectively and reduce the risk of their future growth.<br><br></p>
							</div>

						</div>
						<div class="col-md-4 banner-grid2">
							<div class="banner-subg1">
								<i class="fa fa-bug" style="font-size:36px"></i>
								<h3>Pest Prevention</h3>
								<p>Prevention is better than cure; we apply the scientific approach to protect your home from almost 36 most common types of pest all year long and also eliminate if any already invaded your home. With the detailed study and experience, we apply the chemicals to check the most common types of pests like rodents, termites, cockroaches etc.<br><br></p>
							</div>
							<div class="banner-subg1">
								<i class="fa fa-check-square" style="font-size:36px;"></i>
								<h3>Instant solution</h3>
								<p>Panicked by discovering the whole colony of pests in your living space or office area, don’t worry we offer instant and the best pest control solution in Delhi-NCR to eliminate the unwanted Pests from your space. We provide instant service to give you immediate relief from pests and with further inspection, we check their future growth.  
								</p><br>
							</div>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
		<!-- //banner bottom -->

		<section class="container">
		<div class="row no-gutters">
			<div class="col-6 col-md-4"><img src="images/ce-pipes.jpg"></div>
  			<div class="col-12 col-sm-6 col-md-8">
  				<div class="section-title">
					<h3 style="font-size: 40px; font-weight: bold;">CE-Pipe Anti Termite Treatment</h3><br>
					<p style="color: #000; margin-top: 10px; font-size: 15px; text-align: justify;">A unique and latest concept specially designed CE porous pipe for subsurface application meaning laid below the surface of the soil for continuous discharge of pesticides, insecticides for uniform distribution of chemical below the soil to completely eradicate from the soil.
					This pipe has long functioning life of about 50 yers+.
					Gives care & convenience of application of pesticides and termiticide as and when required through centrally connected Junction box.
					No drilling of expensive floorings like vitrified tiles, granite, marble and industrial flooring.</p>
				</div>

  			</div>
		</div>
	</section><br>

		<!-- PEST CONTROL -->
		<div class="section pest-control bgc">
			<div class="container">
			
				<div class="row">
					<div class="col-sm-6 col-md-6">
						<div class="section-title">
							<h3 style="font-size: 40px; font-weight: bold;">Pest Control</h3>
						</div><br>
					</div>
				</div>
				
				<div class="row">
					<div class="col-sm-4 col-md-3">
						<div class="box-image">
							<div class="image">
								<img src="images/pest-1.jpg" alt="Pest Control Delhi" class="img-responsive">
							</div>
							<div class="description">
								<h5 class="blok-title">
									APROACH SERVICE / COCKROACH CONTROL
								</h5>
							</div>
						</div>
					</div>
					<div class="col-sm-4 col-md-3">
						<div class="box-image">
							<div class="image">
								<img src="images/pest-8.jpg" alt="Pest Control Delhi" class="img-responsive">
							</div>
							<div class="description">
								<h5 class="blok-title">RATRAP SERVICE / RODENT CONTROL
								</h5>
							</div>
						</div>
					</div>
					<div class="col-sm-4 col-md-3">
						<div class="box-image">
							<div class="image">
								<img src="images/pest-2.jpg" alt="Pest Control Delhi" class="img-responsive">
							</div>
							<div class="description">
								<h5 class="blok-title">
									BED BUGS SERVICE<br>
								</h5>
							</div>
						</div>
					</div>

					<div class="col-sm-4 col-md-3">
						<div class="box-image">
							<div class="image">
								<img src="images/pest-6.jpg" alt="Pest Control Noida " class="img-responsive">
							</div>
							<div class="description">
								<h5 class="blok-title">
									TERMINATOR SERVICE / ANTI TERMITE TREATMENT
								</h5>
							</div>
						</div>
					</div>

					<div class="col-sm-4 col-md-3">
						<div class="box-image">
							<div class="image">
								<img src="images/pest-5.jpg" alt="Pest Control Noida " class="img-responsive">
							</div>
							<div class="description">
								<h5 class="blok-title">
									MOSQUITO CONTROL
								</h5>
							</div>
						</div>
					</div>
					
					<div class="col-sm-4 col-md-3">
						<div class="box-image">
							<div class="image">
								<img src="images/pest-7.jpg" alt="Pest Control Noida " class="img-responsive">
							</div>
							<div class="description">
								<h5 class="blok-title">
									ANT CONTROL
								</h5>
							</div>
						</div>
					</div>
					
					<div class="col-sm-4 col-md-3">
						<div class="box-image">
							<div class="image">
								<img src="images/pest-3.jpg" alt="Pest Control Noida" class="img-responsive">
							</div>
							<div class="description">
								<h5 class="blok-title">MAXIFOG SERVICE
								</h5>
							</div>
						</div>
					</div>
					<div class="col-sm-4 col-md-3">
						<div class="box-image">
							<div class="image">
								<img src="images/pest-4.jpg" alt="Pest Control Noida " class="img-responsive">
							</div>
							<div class="description">
								<h5 class="blok-title">BEES CONTROL
								</h5>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>

		<section class="container">
		<div class="row no-gutters">
			<div class="col-6 col-md-4"><img src="images/pest.jpg"></div>
  			<div class="col-12 col-sm-6 col-md-8">
  				<div class="section-title">
					<h3 style="font-size: 40px; font-weight: bold;">Welcome to Pestman Pest Control</h3><br>
					<p style="color: #000; margin-top: 10px; font-size: 15px; text-align: justify;">Pestman Bed Bug control is a name of an immensely regarded organization deals with Pest Control Services in Delhi & NCR. We use Eco-friendly and Odourless pesticides which are hard on pests but harmless for human health. We are backed by the highly skilled and trained workforce for pest control in Delhi-NCR providing Herbal Pest Control to your living spaces, Offices, Industries, Hotels and Corporate Hubs of Delhi-NCR. Our Pest Control Services is not only effective but also check the future growth of pests. We are supported by an efficient administration and very much created organization we put our association as a noticeable association in Delhi. With a rich ordeal of more than 10 years, we have effectively established ourselves as a best Pest Control Company in Delhi-NCR for Domestic, Commercial and Industrial Pest Control. With the opportune execution of our quality Pest Control Services at a very economical price, we recognized as the best Pest Control Company of Delhi-NCR. <br>With the help of our specialists and experts, we are able to provide a substantial cluster of value administration. Various prestigious Hospitals, acclaimed Hotels, and MNC are the list of our happy clientele.   </p>
				</div>

  			</div>
		</div>
	</section><br>

		
	
		<!-- about -->
	
		<div class="agile-about-main">
			<div class="col-md-4 about-left">
				<div class="about-main-bg text-center">
					<h4 class="about-title">Why</h4>
					<h4 class="sub">
						<span>c</span>hoose
						<span>u</span>s?</h4><br><br>
					<h3 class="sub">One Stop Solution for your Complete Pest Control</h3>
				</div>
			</div>
			<div class="col-md-8 about-bottom-g1">
				<div class="about-grid">
					<div class="about-bottom-right">
						
						<div class="about-bottom">
							<div class="abouthome-grid">
							<span class="hi-icon hi-icon-archive fa fa-check"> </span>
						</div>
							<h5>5 STAR PROTECTION</h5><br>
							<p>We offer complete pest control solution in Delhi-NCR by eliminating the pest and also check their growth in future. We conduct the scheduled inspection of your home/office and eliminate if any present in your property. We use eco-friendly chemicals which are hard on pests but soft on your health.</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="about-bottom-right">
						
						<div class="about-bottom">
							<div class="abouthome-grid">
							<span class="hi-icon hi-icon-archive  fa fa-book"> </span>
						</div>
							<h5>PUBLIC HEALTH</h5><br>
							<p>We also educate public regarding the harmful effects of neglecting pest in their living spaces. Being the pest controllers in Delhi-NCR our job not just to kill the pest but also to devise the further measures to check their growth and maintain the ecological balance by using the eco-friendly chemicals so that these chemicals do not affect our health and check the pest growth effectively.</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class=" about-bottom-right">
						
						<div class="about-bottom">
							<div class="abouthome-grid">
							<span class="hi-icon hi-icon-archive fa fa-photo"> </span>
						</div>
							<h5>ENVIRONMENTAL RESPONSIBILITY</h5><br>
							<p>It's our duty to eliminate or check the growth of the pest in your home/ offices so that we can protect you from many dangerous diseases. But not on the cost of the environment as a whole, we use the herbal eco-friendly chemical which is not only very effective but also does not cause any harm to nature and human health. </p>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
				<div class="abt-img">
					<img src="images/a2.gif" alt="" class="img-responsive" />
				</div>
				<div class="clearfix"></div>
			</div>

			<div class="clearfix"></div>
		</div>
	
		
	</div><br>
	<!-- //about -->

	

	<!-- footer -->
	<footer>
    <div class="footerHeader" ></div>
    <div class="container">
		<div class="col-md-4" >
		    <h3>About us</h3>
		    <p>
		        Pestman is one of the fast growing Companies for Pest Control in India over the last decade. We are renowned nationwide for our superior quality and excellent efficiency. We are backed by the highly skilled workforce who not only eliminate pest but also check their future growth. This makes us ideal service provider in the highly demanding environment of hotels, corporates, pharma, MNC, and banks. 
				Our services are evaluated and approved by credible organizations like NSIC, PPQS, ISO, and IPCA etc. 
		    </p>
		</div>
		
		<div class="col-md-4">
		    <h3>Our Location </h3>
		    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d27997.97471071006!2d77.11772509839214!3d28.69721866752763!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d033ea90dad3f%3A0x782ce0d7380bd34c!2sPestman+Services!5e0!3m2!1sen!2sin!4v1529751509439" frameborder="0" style="border:0" allowfullscreen></iframe>
		</div>
		<div class="col-md-4" >
		    <h3>Contact Us</h3>
		    <ul>
		    	<li style="font-size: 16px;"><span>Address : </span>Office No. - 322, 3rd Floor, DDA Market,<br>Local Shopping Complex, Samrat Enclave,<br> Pitampura, New Delhi - 110034</li><br>
		        <li style="font-size: 16px;"><span>Phone :</span> +91 82-87-900-800</li><br>
		        <li style="font-size: 16px;""><span>E-mail :</span> info@pest-man.com</li>
		    </ul><br>
		    <!-- <ul class="sm">
		        <a href="https://www.facebook.com/Pestman-616272795439179/"><i class="fa fa-facebook-square" style="font-size:36px"></i></a>
					<a href="https://plus.google.com/u/0/100968207712771263814"><i class="fa fa-google-plus-square" aria-hidden="true" style="font-size:36px"></i></a>
					<a href="https://twitter.com/pestman6"><i class="fa fa-twitter-square" aria-hidden="true" style="font-size:36px"></i></a>
					<a href="https://www.linkedin.com/company/pestman/"><i class="fa fa-linkedin-square" style="font-size:36px"></i></a>
					<a href="https://www.instagram.com/pestmandelhincr/"><i class="fa fa-instagram" style="font-size:36px"></i></a>
		    </ul> -->
		</div>
    </div>



	<div class="cpy-footer">
		<div class="cpy-text">
			<p>© 2018 Pestman. All rights reserved | Designed by
				<a href="http://uniworldstudios.com/">Uniworld Studios</a>
			</p>
		</div>

	</div>
	</footer>
	<!--//footer  -->
	<!-- js -->
	<script src="js/jquery-2.2.3.min.js"></script>
	<!-- //js-->
	<!--banner-slider-->
	<script src="js/JiSlider.js"></script>
	<script> 
		$(window).load(function () {
			$('#JiSlider').JiSlider({
				color: '#fff',
				start: 1,
				reverse: false
			}).addClass('ff')
		})
	</script>
	<!-- //banner-slider -->
	<!--search-bar-->
	<script src="js/main.js"></script>
	<!--//search-bar-->
	<!-- start-smooth-scrolling -->
	<script  src="js/move-top.js"></script>
	<script  src="js/easing.js"></script>
	<script> 
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();

				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- //end-smooth-scrolling -->
	<!-- smooth-scrolling-of-move-up -->
	<script> 
		$(document).ready(function () {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/

			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>
	<script  src="js/SmoothScroll.min.js"></script>
	<!-- Bootstrap core JavaScript
    ================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<script src="js/bootstrap.js"></script>
</body>

</html>
