<?php
if(isset($_POST["submit"])){
// Checking For Blank Fields..
if($_POST["name"]==""||$_POST["mobile"]==""){
echo "Fill All Fields..";
}else{
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['mobile'];
$address = $_POST['address'];
$service = $_POST['service'];

function getIp(){

        $ip = $_SERVER['REMOTE_ADDR'];     
        if($ip){
            if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            }
            return $ip;
        }
        // There might not be any data
        return false;
    }

$user_ip = getIp();



$email_from = 'sales@pest-man.com';
$subject = "A New Query Received for Pest Control";

$message = '<html><body>';
$message .= '<h2 style="color:#f40;">You have received a new Query from the Customer</h2>';
$message .= '<h4>Name: </h4>';
$message .= "$name";
$message .= '<h4>Email: </h4>';
$message .= "$email";
$message .= '<h4>Phone: </h4>';
$message .= "$phone";
$message .= '<h4>Address: </h4>';
$message .= "$address";
$message .= '<h4>Service: </h4>';
$message .= "$service";
$message .= '<h4>User IP Address: </h4>';
$message .= "$user_ip";

$message .= '</body></html>';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
 
// Create email headers
$headers .= 'From: '.$email_from."\r\n".
    'Reply-To: '.$email_from."\r\n" .
    'X-Mailer: PHP/' . phpversion();
// Message lines should not exceed 70 characters (PHP rule), so wrap it
$message = wordwrap($message, 70);
// Send Mail By PHP Mail Function
mail("info@pest-man.com, pestmandelhincr@gmail.com", $subject, $message, $headers);
header('Location: thankyou.php');

}
}
?>